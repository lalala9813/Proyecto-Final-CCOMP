PASOS PARA LA INSTALACION DEL PROYECTO FINAL

1.Ejecutar FinalProject.exe y seguir los pasos
2.Abrir sfml-test.cbp en Code::Blocks (Es necesario tener instalado Code::Blocks)
3.Ya en Code::Blocks hacer click derecho sobre sfml-test y en el proyecto indicar los paths para sfml/include y sfml/lib


Nota:Para ver paso por paso como indicar los paths para sfml, visitar:
http://www.edparrish.net/common/sfmlcb.html
y seguir las instrucciones a partir del punto C. 6.

SFML esta incluido en el instalador.
La ubicaci�n est� al mismo nivel que la carpeta del proyecto.
los paths deber�an ser:
#Para el include:
 {Carpeta de instalaci�n}/sfml/include

#Para el lib:
 {Carpeta de instalaci�n}/sfml/lib